public interface EndpointCollection {
}